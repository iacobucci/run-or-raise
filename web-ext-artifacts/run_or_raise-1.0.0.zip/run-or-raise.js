var enabled_links = ['https://open.spotify.com', 'https://web.whatsapp.com/', 'https://web.telegram.org', 'https://www.google.com/maps'];

// var loadLinks = browser.storage.sync.get('links');

// loadLinks.then((res) => {
// 	document.querySelector("#user_selectable").value = res.links || 'Firefox red';
// });

var enabled_links_patterns = [];

function pattern_url(url) {
	if (url[url.length - 1] == "/")
		return url.split("://")[1].substring(0, url.split("://")[1].length - 1);
	else
		return url.split("://")[1];
}
enabled_links.forEach((x) => {
	enabled_links_patterns.push(pattern_url(x))
});

function onError(error) {
	console.log(`Error: ${error}`);
}

function handleUpdated(tabId, changeInfo, currentTab) {

	console.log(currentTab.url, changeInfo);

	let matchedTab = false;
	let querying = browser.tabs.query({});

	querying.then((tabs) => {

		for (let i = 0; i < enabled_links_patterns.length; i++) {
			if (currentTab.url.search(enabled_links_patterns[i]) > 0) {
				matchedTab = currentTab;
				matchedLinkIndex = i;
				break;
			}
		}

		let movingTab = false;
		if (matchedTab) {
			for (let tab of tabs) {
				if (tab.url.search(pattern_url(matchedTab.url)) > 0 && tab.id != matchedTab.id) {
					movingTab = tab;
					break;
				}
			}

			if (movingTab) {
				let updatingwindow = browser.windows.update(movingTab.windowId, {
					focused: true
				});

				updatingwindow.then(() => {

					let updatingtab = browser.tabs.update(movingTab.id, {
						active: true
					});

					updatingtab.then(() => {

						let removing = browser.tabs.remove(matchedTab.id);
						removing.then(() => {

						})
					});
				});


			} else {

				if (Object.keys(changeInfo).includes("status")) {
					if (changeInfo.status = "complete") {
						let ix = 0;
						for (let i = 0; i < enabled_links_patterns.length; i++) {
							if (tabs[i].url.search(enabled_links_patterns[i]) > 0)
								ix++;
							else
								break;
						}

						let moving = browser.tabs.move(matchedTab.id, {
							index: ix
						});
					}
				}
			}
		}
	}, () => {});
}

browser.tabs.onUpdated.addListener(handleUpdated);
